# IntelliTradeAI Project Structure

## Directory Organization

```
IntelliTradeAI/
├── app/                          # Frontend application
│   └── enhanced_dashboard.py     # Main Streamlit dashboard with UI
│
├── models/                       # Machine Learning models
│   ├── model_trainer.py         # RobustModelTrainer - training pipeline
│   ├── random_forest_model.py   # Random Forest implementation
│   ├── xgboost_model.py         # XGBoost implementation
│   ├── lstm_model.py            # LSTM neural network (optional)
│   ├── model_comparison.py      # Model comparison framework
│   └── cache/                   # Trained model files (*.joblib)
│       ├── BTC_random_forest.joblib
│       ├── ETH_random_forest.joblib
│       └── ... (36 total models)
│
├── data/                         # Data ingestion layer
│   ├── data_ingestion.py        # Main API integration (CMC + Yahoo)
│   ├── crypto_data_fetcher.py   # Cryptocurrency data fetcher
│   ├── top_coins_manager.py     # Dynamic top coins discovery
│   ├── enhanced_crypto_fetcher.py  # Multi-coin fetcher
│   ├── crypto_data.json         # Cached crypto data
│   └── stock_data.json          # Cached stock data
│
├── ai_advisor/                   # AI analysis engines
│   ├── ml_predictor.py          # ML prediction engine
│   ├── signal_fusion_engine.py  # Conflict resolution system
│   └── price_level_analyzer.py  # Support/resistance analysis
│
├── ai_vision/                    # Technical analysis
│   └── chart_pattern_recognition.py  # Chart pattern detection
│
├── utils/                        # Utility modules
│   ├── indicators.py            # Technical indicators (RSI, MACD, etc.)
│   ├── data_cleaner.py          # Data validation and cleaning
│   └── explainability.py        # SHAP analysis for interpretability
│
├── .streamlit/                   # Streamlit configuration
│   └── config.toml              # Server settings (port 5000)
│
├── main.py                       # FastAPI backend server
├── README.md                     # Project overview (from replit.md)
├── IMPLEMENTATION_GUIDE.md       # Testing & implementation guide
├── ACTIVITY_DIAGRAM.md          # System flow diagrams
├── SETUP_INSTRUCTIONS.md        # Setup and installation guide
├── PROJECT_STRUCTURE.md         # This file
├── requirements.txt             # Python dependencies
├── pyproject.toml               # UV package manager config
└── IntelliTradeAI_Research_Paper.pdf  # Academic research paper
```

## Key Components

### Frontend Layer (Streamlit)

**File**: `app/enhanced_dashboard.py`

**Responsibilities**:
- User authentication and session management
- Interactive dashboard with multiple pages
- Asset selection interface (36 assets)
- Real-time prediction display
- Interactive charts with Plotly
- Signal fusion visualization
- Support/resistance level display

**Key Functions**:
- `render_ai_analysis_page()` - Main analysis interface
- `render_backtesting_page()` - Backtesting interface
- `display_prediction_card()` - Prediction visualization
- `create_interactive_chart()` - Chart generation

### Backend Layer (FastAPI)

**File**: `main.py`

**Endpoints**:
- `GET /` - Health check
- `POST /retrain` - Trigger model retraining
- `GET /data` - Fetch market data
- `POST /predict` - Get predictions
- `GET /models` - List available models
- `GET /health` - System status

### Machine Learning Pipeline

#### Model Trainer
**File**: `models/model_trainer.py`

**Class**: `RobustModelTrainer`

**Capabilities**:
- End-to-end training pipeline
- Feature engineering (80+ features)
- Hyperparameter optimization
- Model evaluation and metrics
- Model serialization (joblib)

**Methods**:
- `run_comprehensive_training()` - Complete training workflow
- `engineer_features()` - Create 80 technical features
- `prepare_training_data()` - Train/test split and scaling
- `train_random_forest()` - Random Forest training
- `save_model()` - Model persistence

#### Individual Models
- **Random Forest** (`random_forest_model.py`) - Ensemble method
- **XGBoost** (`xgboost_model.py`) - Gradient boosting
- **LSTM** (`lstm_model.py`) - Deep learning for time series

### Data Layer

#### Data Ingestion
**File**: `data/data_ingestion.py`

**Class**: `DataIngestion`

**Methods**:
- `fetch_crypto_data()` - CoinMarketCap + Yahoo Finance
- `fetch_stock_data()` - Yahoo Finance stocks
- `_fetch_from_coinmarketcap()` - CMC API integration
- `_enrich_with_coinmarketcap()` - Add CMC metadata

**Caching**:
- JSON-based caching system
- Configurable TTL
- Multi-symbol support

### AI Advisor Layer

#### ML Predictor
**File**: `ai_advisor/ml_predictor.py`

**Class**: `MLPredictor`

**Workflow**:
1. Load trained model
2. Engineer features (same 80 as training)
3. Scale features
4. Generate prediction
5. Calculate confidence
6. Return signal (BUY/SELL/HOLD)

#### Signal Fusion Engine
**File**: `ai_advisor/signal_fusion_engine.py`

**Class**: `SignalFusionEngine`

**Purpose**: Resolve conflicts between ML and pattern recognition

**Logic**:
- If both agree → Use higher confidence
- If both disagree with high confidence → HOLD (safety)
- If one is HOLD → Use the stronger signal
- Always show both insights for transparency

#### Price Level Analyzer
**File**: `ai_advisor/price_level_analyzer.py`

**Class**: `PriceLevelAnalyzer`

**Purpose**: Identify actionable price levels for HOLD signals

**Features**:
- Support level detection
- Resistance level detection
- Confidence scoring
- BUY/SELL recommendations at specific prices

### AI Vision Layer

**File**: `ai_vision/chart_pattern_recognition.py`

**Class**: `ChartPatternRecognizer`

**Patterns Detected**:
- Head and Shoulders
- Double Top/Bottom
- Triangle patterns
- Flag patterns
- Channel patterns

### Utilities

#### Technical Indicators
**File**: `utils/indicators.py`

**Indicators**: 50+ technical indicators including:
- RSI (Relative Strength Index)
- MACD (Moving Average Convergence Divergence)
- Bollinger Bands
- Moving Averages (SMA, EMA)
- Momentum indicators
- Volume indicators
- Volatility metrics

#### Data Cleaner
**File**: `utils/data_cleaner.py`

**Functions**:
- Remove duplicates
- Handle missing values
- Validate OHLCV data
- Outlier detection
- Data type conversions

## Data Flow

### Prediction Request Flow

```
User (Dashboard) 
    → Select Asset + Period
    → Click "Run Analysis"
    → data_ingestion.py
        → Fetch from APIs (CMC + Yahoo)
        → Cache data
    → ml_predictor.py
        → Load trained model
        → Engineer features (80)
        → Predict + confidence
    → signal_fusion_engine.py
        → Combine ML + Pattern signals
        → Resolve conflicts
    → Dashboard
        → Display results
        → Show charts
        → Provide insights
```

### Training Pipeline Flow

```
User triggers training
    → model_trainer.py
        → Fetch 2 years of data
        → Engineer 80 features
        → Train/test split (80/20)
        → Hyperparameter tuning
        → Train Random Forest
        → Evaluate metrics
        → Save model (*.joblib)
    → Model ready for predictions
```

## Configuration Files

### `.streamlit/config.toml`
- Server address: 0.0.0.0
- Port: 5000
- Headless mode: true

### `pyproject.toml`
- UV package manager configuration
- Python version: 3.11
- All dependencies listed

### `requirements.txt`
- Standalone pip installation
- 29 core dependencies
- Compatible with Python 3.11+

## Model Files

**Location**: `models/cache/`

**Format**: Joblib pickle files (*.joblib)

**Count**: 36 trained models
- 20 cryptocurrency models
- 18 stock models

**Size**: ~1-5 MB per model

**Training Data**: 2 years of OHLCV data per asset

## Asset Coverage

### Cryptocurrencies (20)
BTC, ETH, USDT, XRP, BNB, SOL, USDC, TRX, DOGE, ADA, AVAX, SHIB, TON, DOT, LINK, BCH, LTC, XLM, WTRX, STETH

### Stocks (18)
AAPL, MSFT, GOOGL, AMZN, NVDA, META, TSLA, JPM, WMT, JNJ, V, BAC, DIS, NFLX, INTC, AMD, CRM, ORCL

## Technology Stack

- **Frontend**: Streamlit 1.x
- **Backend**: FastAPI + Uvicorn
- **ML Framework**: Scikit-learn (Random Forest), XGBoost, TensorFlow (LSTM)
- **Data Sources**: CoinMarketCap API, Yahoo Finance (yfinance)
- **Visualization**: Plotly
- **Data Processing**: Pandas, NumPy
- **Model Serialization**: Joblib
- **Environment**: Python 3.11

---

**Last Updated**: November 22, 2025  
**Version**: 1.0  
**Total Lines of Code**: ~15,000+
