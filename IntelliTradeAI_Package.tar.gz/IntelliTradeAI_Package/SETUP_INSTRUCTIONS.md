# IntelliTradeAI Setup Instructions

## Prerequisites
- Python 3.11 or higher
- Internet connection for fetching market data

## Installation Steps

### 1. Install Dependencies
```bash
pip install -r requirements.txt
```

### 2. Set Up Environment Variables
Create a `.env` file in the project root with your CoinMarketCap API key:
```
COINMARKETCAP_API_KEY=your_api_key_here
```

You can get a free API key from: https://coinmarketcap.com/api/

### 3. Run the Application

**Option A: Run the Streamlit Dashboard (Recommended)**
```bash
streamlit run app/enhanced_dashboard.py --server.port 5000
```

**Option B: Run with FastAPI Backend**
```bash
# Terminal 1: Start FastAPI backend
uvicorn main:app --host 0.0.0.0 --port 8000 --reload

# Terminal 2: Start Streamlit dashboard
streamlit run app/enhanced_dashboard.py --server.port 5000
```

### 4. Access the Application
- **Dashboard**: http://localhost:5000
- **API** (if running): http://localhost:8000
- **API Docs**: http://localhost:8000/docs

## Supported Assets

### Cryptocurrencies (20)
BTC, ETH, USDT, XRP, BNB, SOL, USDC, TRX, DOGE, ADA, AVAX, SHIB, TON, DOT, LINK, BCH, LTC, XLM, WTRX, STETH

### Stocks (18)
AAPL, MSFT, GOOGL, AMZN, NVDA, META, TSLA, JPM, WMT, JNJ, V, BAC, DIS, NFLX, INTC, AMD, CRM, ORCL

## Quick Start Guide

1. **Log in** to the dashboard (default credentials may be configured in the app)
2. **Navigate** to "AI Analysis" page
3. **Select assets** from the dropdown (choose any combination of the 36 available)
4. **Choose period**: 1M, 3M, 6M, or 1Y (recommended: 3M or longer for better predictions)
5. **Click** "Run AI Analysis"
6. **Review** predictions with:
   - Signal (BUY/SELL/HOLD)
   - Confidence score (%)
   - Current price
   - Interactive charts
   - Support/resistance levels

## Features

### AI-Powered Predictions
- 36 pre-trained Random Forest models
- 80+ technical indicators per prediction
- Confidence scores for transparency
- Accuracies ranging 47-79%

### Signal Fusion Engine
- Combines ML predictions with chart pattern analysis
- Intelligent conflict resolution
- Visual warnings when AI systems disagree
- Transparent insights from both systems

### Interactive Visualizations
- Price charts with candlesticks
- Toggleable support/resistance levels
- Chart pattern overlays
- Entry/exit points visualization

### Risk Management
- HOLD signals with actionable price levels
- Support/resistance analysis
- Confidence-based recommendations

## Troubleshooting

### Issue: ModuleNotFoundError
**Solution**: Make sure all dependencies are installed:
```bash
pip install -r requirements.txt
```

### Issue: API Rate Limit Errors
**Solution**: The app has built-in caching and rate limiting. Wait a few minutes and try again.

### Issue: No Data for Asset
**Solution**: Some assets may have limited data availability. Try:
- Using a longer time period (3M or 6M instead of 1M)
- Checking if the asset ticker is correct
- Verifying internet connection

### Issue: Low Confidence Predictions
**Solution**: This is normal and indicates market uncertainty. Consider:
- Using longer analysis periods
- Checking multiple assets for correlation
- Using HOLD recommendations to wait for better entry points

## Project Structure

For detailed information about the codebase organization, see `PROJECT_STRUCTURE.md`

## Documentation

- **README.md**: Project overview and recent changes
- **IMPLEMENTATION_GUIDE.md**: Detailed implementation and testing guide
- **ACTIVITY_DIAGRAM.md**: System flow diagrams
- **IntelliTradeAI_Research_Paper.pdf**: Academic research paper

## Support

For issues or questions:
1. Check the documentation files
2. Review the research paper for methodology
3. Inspect the activity diagrams for system understanding

---

**Version**: 1.0  
**Last Updated**: November 22, 2025  
**Total Assets**: 36 (20 cryptocurrencies + 18 stocks)
